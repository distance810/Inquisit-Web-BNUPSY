# 所需工具模块
from PIL import Image
from PIL import ImageDraw

# 设置工作路径
workdir = "/Users/nishishabi/Desktop/实心实验作业/蒙浩然_差别阈限/"

# 图片灰度化
im = Image.open(workdir+"Lana.jpg").convert('L')

# 图片灰度梯度
draw = ImageDraw.Draw(im)
for x in range(1, 17):
    for i in range(0, list(im.size)[0]):
            for j in range(0, list(im.size)[1]):
                    color = im.getpixel((i, j))
                    # 改变灰度值
                    color = color + x
                    point = [i, j]
                    draw.point(point, color)
    im.save(str(x-1)+'.jpg')

# 打印出inquisit中所需的图片名格式
print("<item greypics>")
for i in range(1, 16):
    print('  ' + '/' + str(i) + ' = ' + '"' + str(i) + '.jpg'+'"')
print("</item>")
print("\n")
